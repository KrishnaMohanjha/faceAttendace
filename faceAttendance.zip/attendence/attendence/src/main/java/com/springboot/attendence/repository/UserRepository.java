package com.springboot.attendence.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.attendence.Entity.User;

public interface UserRepository extends JpaRepository<User, UUID>  {

	 Optional<User> findByMobileNumber(String mobileNumber);
	 boolean existsByMobileNumber(String mobileNumber);
	User getByMobileNumber(String mobileNumber);
	
}
