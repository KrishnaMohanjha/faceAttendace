package com.springboot.attendence.Service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.model.*;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.S3Object;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

@Service
public class FacialRecognitionService {

	 private final AmazonRekognition rekognitionClient;
	 private final UserService userService;

	    public FacialRecognitionService(UserService userService,AmazonRekognition rekognitionClient) {
	        this.rekognitionClient = rekognitionClient;
	        this.userService = userService;
	    }

	    public boolean compareFaces(String registeredPhotoUrl, MultipartFile currentPhoto, String mobileNumber) {
	        String registeredPhotoUrl1 = userService.getUserPhotoUrl(mobileNumber);
	        if (registeredPhotoUrl1 == null) {
	            return false; // Handle case where user photo URL is not found
	        }
	        try {
	            // Create Image from the current photo using ByteBuffer
	            Image sourceImage = new Image().withBytes(ByteBuffer.wrap(currentPhoto.getBytes()));

	            // Retrieve the target image bytes from S3
	            byte[] targetImageBytes = retrieveImageBytesFromS3("aieze-website", registeredPhotoUrl1);
	            if (targetImageBytes == null) {
	                return false; // Handle case where the target image could not be retrieved
	            }

	            // Wrap the byte array in a ByteBuffer for the target image
	            ByteBuffer targetImageBuffer = ByteBuffer.wrap(targetImageBytes);

	            // Create the Image object for the target image using ByteBuffer
	            Image targetImage = new Image().withBytes(targetImageBuffer);

	            // Prepare and send the compare faces request
	            CompareFacesRequest request = new CompareFacesRequest()
	                    .withSourceImage(sourceImage)
	                    .withTargetImage(targetImage)
	                    .withSimilarityThreshold(80F);

	            // Compare faces using Rekognition client
	            CompareFacesResult result = rekognitionClient.compareFaces(request);
	            for (CompareFacesMatch match : result.getFaceMatches()) {
	                return match.getSimilarity() > 80.0; // Return true if similarity is greater than 80%
	            }
	        } catch (AmazonRekognitionException e) {
	            System.err.println("Error comparing faces: " + e.getMessage());
	        } catch (IOException e) {
	            System.err.println("Error reading photo bytes: " + e.getMessage());
	        }
	        return false; // Default return false if no match found or an error occurred
	    }

	    private byte[] retrieveImageBytesFromS3(String bucketName, String objectKey) {
	        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                    .withRegion(Regions.AP_SOUTH_1) 
                    .build();
	        try {
	            System.out.println("Attempting to retrieve object from S3. Bucket: " + bucketName + ", Key: " + objectKey);
	            
	            String fullUrl = objectKey;
	            String key = fullUrl.substring(fullUrl.lastIndexOf("/") + 1);
	            // Attempt to get the S3 object
	            S3Object s3Object = s3Client.getObject(bucketName, key);
	            try (InputStream inputStream = s3Object.getObjectContent();
	                 ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

	                byte[] buffer = new byte[1024];
	                int bytesRead;
	                while ((bytesRead = inputStream.read(buffer)) != -1) {
	                    outputStream.write(buffer, 0, bytesRead);
	                }
	                System.out.println("Successfully retrieved and read the S3 object.");
	                return outputStream.toByteArray(); // Return the byte array of the image
	            } catch (IOException e) {
	                System.err.println("Error reading S3 object content: " + e.getMessage());
	                e.printStackTrace();
	                return null; // Return null if an error occurs
	            }
	        } catch (AmazonS3Exception e) {
	            System.err.println("AmazonS3Exception: Error retrieving object from S3: " + e.getMessage());
	            e.printStackTrace();
	            return null; // Return null if an error occurs
	        } catch (Exception e) {
	            System.err.println("Unexpected error: " + e.getMessage());
	            e.printStackTrace();
	            return null; // Return null for any other errors
	        }
	    }



}
