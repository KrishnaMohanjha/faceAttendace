package com.springboot.attendence.DTO;

import java.util.UUID;






public class UserRegistrationDto {

	private UUID userId;
    public UUID getUserId() {
		return userId;
	}
	public void setUserId(UUID userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	private String name;
    private String mobileNumber;
	public UserRegistrationDto(UUID userId, String name, String mobileNumber) {
		
		this.userId = userId;
		this.name = name;
		this.mobileNumber = mobileNumber;
	}

}
