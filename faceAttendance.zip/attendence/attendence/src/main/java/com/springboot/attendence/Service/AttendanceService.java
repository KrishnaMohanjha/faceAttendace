package com.springboot.attendence.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.springboot.attendence.Entity.Attendance;
import com.springboot.attendence.repository.AttendanceRepository;

@Service
public class AttendanceService {
    private final AttendanceRepository attendanceRepository;

    public AttendanceService(AttendanceRepository attendanceRepository) {
        this.attendanceRepository = attendanceRepository;
    }

    public String checkIn(String mobileNumber) {
        Optional<Attendance> attendanceOpt = attendanceRepository.findByMobileNumberAndCheckOutTimeIsNull(mobileNumber);
        if (attendanceOpt.isPresent()) {
            return "Already checked in.";
        }

        Attendance attendance = new Attendance();
        attendance.setMobileNumber(mobileNumber);
        attendance.setCheckInTime(LocalDateTime.now());

        attendanceRepository.save(attendance);
        return "Check-in successful";
    }

    public String checkOut(String mobileNumber) {
        Optional<Attendance> attendanceOpt = attendanceRepository.findByMobileNumberAndCheckOutTimeIsNull(mobileNumber);
        if (!attendanceOpt.isPresent()) {
            return "No check-in record found.";
        }

        Attendance attendance = attendanceOpt.get();
        attendance.setCheckOutTime(LocalDateTime.now());

        if (attendance.getTotalHours() >= 8) {
            attendanceRepository.save(attendance);
            return "Check-out successful";
        } else {
            return "Minimum working hours not completed.";
        }
    }
}