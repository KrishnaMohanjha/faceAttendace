package com.springboot.attendence.DTO;

public class CheckInRequest {

	 private String mobileNumber;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public CheckInRequest(String mobileNumber) {
		
		this.mobileNumber = mobileNumber;
	}
}
