package com.springboot.attendence.Controler;

import java.util.Optional;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.springboot.attendence.DTO.CheckInRequest;
import com.springboot.attendence.Entity.User;
import com.springboot.attendence.Service.AttendanceService;
import com.springboot.attendence.Service.FacialRecognitionService;
import com.springboot.attendence.Service.UserService;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;
    private final UserService userService;
    private final FacialRecognitionService facialRecognitionService;

    public AttendanceController(AttendanceService attendanceService, UserService userService, FacialRecognitionService facialRecognitionService) {
        this.attendanceService = attendanceService;
        this.userService = userService;
        this.facialRecognitionService = facialRecognitionService;
    }

    @PostMapping("/check-in")
    public ResponseEntity<String> checkIn(@RequestPart("photo") MultipartFile photo,
                                           @RequestPart("checkInRequest") CheckInRequest checkInRequest) throws Exception {
        String mobileNumber = checkInRequest.getMobileNumber();
        
        // Retrieve user and photo URL
        Optional<User> userOpt = userService.getUserByMobileNumber(mobileNumber);
        if (!userOpt.isPresent()) {
            return ResponseEntity.badRequest().body("User not found");
        }
        
        String photoUrl = userOpt.get().getPhotoUrl();

        // Compare faces
        boolean faceMatch = facialRecognitionService.compareFaces(photoUrl, photo, mobileNumber);
        if (faceMatch) {
            return ResponseEntity.ok(attendanceService.checkIn(mobileNumber));
        } else {
            return ResponseEntity.status(401).body("Face does not match");
        }
    }

    @PostMapping("/check-out")
    public ResponseEntity<String> checkOut(@RequestPart("photo") MultipartFile photo,
                                            @RequestPart("checkInRequest") CheckInRequest checkInRequest) throws Exception {
        String mobileNumber = checkInRequest.getMobileNumber();

        // Retrieve user and photo URL
        Optional<User> userOpt = userService.getUserByMobileNumber(mobileNumber);
        if (!userOpt.isPresent()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        String photoUrl = userOpt.get().getPhotoUrl();

        // Compare faces
        boolean faceMatch = facialRecognitionService.compareFaces(photoUrl, photo, mobileNumber);
        if (faceMatch) {
            return ResponseEntity.ok(attendanceService.checkOut(mobileNumber));
        } else {
            return ResponseEntity.status(401).body("Face does not match");
        }
    }
}