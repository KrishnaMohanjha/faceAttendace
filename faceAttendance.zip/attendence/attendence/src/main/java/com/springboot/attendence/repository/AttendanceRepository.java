package com.springboot.attendence.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.attendence.Entity.Attendance;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

	  Optional<Attendance> findByMobileNumberAndCheckOutTimeIsNull(String mobileNumber);
}
