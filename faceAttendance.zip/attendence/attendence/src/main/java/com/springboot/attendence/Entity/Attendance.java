package com.springboot.attendence.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "attendence_registration")
@Data
public class Attendance {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Long id;
	@Column(name = "user_id")
    private UUID userId;
	@Column(name = "check_In_Time")
    private LocalDateTime checkInTime;
	@Column(name = "check_Out_Time")
    private LocalDateTime checkOutTime;
	@Column(name = "mobile_Number")
	private String mobileNumber;
    
    public long getTotalHours() {
        if (checkInTime != null && checkOutTime != null) {
            return java.time.Duration.between(checkInTime, checkOutTime).toHours();
        }
        return 0;
    }

}
