package com.springboot.attendence.Service;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.springboot.attendence.Entity.User;
import com.springboot.attendence.repository.UserRepository;

@Service
public class UserService {

	   private final UserRepository userRepository;
	    private final S3Service s3Service;

	    public UserService(UserRepository userRepository, S3Service s3Service) {
	        this.userRepository = userRepository;
	        this.s3Service = s3Service;
	    }
	    
	    public User registerUser(UUID userId, String name,String mobileNumber, MultipartFile photo) throws IOException {
	        // Upload photo to S3
	        String photoUrl = s3Service.uploadFile(photo);

	        User user = new User();
	        user.setUserId(userId);
	        user.setName(name);
	        user.setPhotoUrl(photoUrl);
	        user.setMobileNumber(mobileNumber);

	        return userRepository.save(user);
	    }
	    
	    public Optional<User> getUserByMobileNumber(String mobileNumber) {
	        return userRepository.findByMobileNumber(mobileNumber);
	    }

		public boolean existsByMobileNumber(String mobileNumber) {
			return userRepository.existsByMobileNumber(mobileNumber);
		}
		
		public String getUserPhotoUrl(String mobileNumber) {
	        User userPhoto = userRepository.getByMobileNumber(mobileNumber);
	        return userPhoto != null ? userPhoto.getPhotoUrl() : null;
	    }
}
