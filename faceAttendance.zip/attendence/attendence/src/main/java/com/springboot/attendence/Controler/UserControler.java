package com.springboot.attendence.Controler;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.springboot.attendence.DTO.UserRegistrationDto;
import com.springboot.attendence.Entity.User;
import com.springboot.attendence.Service.UserService;

@RestController
@RequestMapping("/users")
public class UserControler {
	
	  private UserService userService = null;

	    public UserControler(UserService userService) {
	        this.userService = userService;
	    }
	
	    @PostMapping("/register")
	    public ResponseEntity<?> registerUser(
	            @RequestPart("user") UserRegistrationDto userRegistrationDto,
	            @RequestParam("photo") MultipartFile photo) throws IOException {

	        // Check if the mobile number already exists
	        if (userService.existsByMobileNumber(userRegistrationDto.getMobileNumber())) {
	            return ResponseEntity.status(HttpStatus.SC_CONFLICT)
	                                 .body("Mobile number already exists.");
	        }

	        // Proceed with registration if mobile number is unique
	        User user = userService.registerUser(
	                userRegistrationDto.getUserId(),
	                userRegistrationDto.getName(),
	                userRegistrationDto.getMobileNumber(),
	                photo);
	        
	        return ResponseEntity.ok(user);
	    }


}
